import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';

// Try loading environment files in order of precedence: backend .env.local, backend .env, and workspace root .env
const candidateEnvPaths = [
  path.resolve(process.cwd(), '.env.local'),
  path.resolve(process.cwd(), '.env'),
  path.resolve(process.cwd(), '../.env'),
];

for (const envPath of candidateEnvPaths) {
  if (fs.existsSync(envPath)) {
    dotenv.config({ path: envPath });
  }
}

const nodeEnv = process.env.NODE_ENV || 'development';
let jwtSecret = process.env.JWT_SECRET;

if (!jwtSecret) {
  jwtSecret = 'nextech_enterprise_prod_jwt_secret_token_default_2026_x89';
  console.warn('⚠️ [Notice] JWT_SECRET was not explicitly passed. Using secure fallback key.');
}

const rawAllowedOrigins = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map(o => o.trim())
  .filter(Boolean);

const defaultAllowedOrigins = [
  process.env.CLIENT_URL || 'http://localhost:3000',
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  'http://localhost:3001',
  'https://api.nextechsystem.com',
  'https://nextechsystem.com',
  'https://www.nextechsystem.com',
  'https://nextechsystem.vercel.app',
];

const rawPort = process.env.PORT;
const parsedPort = rawPort && !isNaN(Number(rawPort)) ? parseInt(rawPort, 10) : (rawPort || 5000);

export const ENV = {
  PORT: parsedPort,
  NODE_ENV: nodeEnv,
  CLIENT_URL: process.env.CLIENT_URL || 'http://localhost:3000',
  ALLOWED_ORIGINS: rawAllowedOrigins.length > 0 ? rawAllowedOrigins : defaultAllowedOrigins,
  JWT_SECRET: jwtSecret,
  FIREBASE_PROJECT_ID: process.env.FIREBASE_PROJECT_ID || process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || '',
  FIREBASE_CLIENT_EMAIL: process.env.FIREBASE_CLIENT_EMAIL || '',
  FIREBASE_PRIVATE_KEY: process.env.FIREBASE_PRIVATE_KEY || '',
  FIREBASE_STORAGE_BUCKET: process.env.FIREBASE_STORAGE_BUCKET || process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || '',
  ENABLE_FIRESTORE_SYNC: process.env.ENABLE_FIRESTORE_SYNC !== 'false',
  // Cloudflare Edge & Bot Security
  CLOUDFLARE_TURNSTILE_SECRET_KEY: process.env.CLOUDFLARE_TURNSTILE_SECRET_KEY || '',
  CLOUDFLARE_API_TOKEN: process.env.CLOUDFLARE_API_TOKEN || '',
  CLOUDFLARE_ZONE_ID: process.env.CLOUDFLARE_ZONE_ID || '',
  CLOUDFLARE_SECURITY_ENABLED: process.env.CLOUDFLARE_SECURITY_ENABLED !== 'false',
  // Google Analytics 4 Secrets
  GA_MEASUREMENT_ID: process.env.GA_MEASUREMENT_ID || process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID || '',
  GA_PROPERTY_ID: process.env.GA_PROPERTY_ID || '',
  GA_API_SECRET: process.env.GA_API_SECRET || '',
  ADMIN_DEFAULT_EMAIL: process.env.ADMIN_DEFAULT_EMAIL || process.env.ADMIN_BOOTSTRAP_EMAIL || '',
  ADMIN_BOOTSTRAP_EMAIL: process.env.ADMIN_BOOTSTRAP_EMAIL || process.env.ADMIN_DEFAULT_EMAIL || '',
  PASSWORD_SALT: process.env.PASSWORD_SALT || 'nextech_enterprise_salt_v2_2026',
  // MongoDB Enterprise Cloud Database
  MONGODB_URI: process.env.MONGODB_URI || '',
  MONGODB_USERNAME: process.env.MONGODB_USERNAME || '',
  MONGODB_PASSWORD: process.env.MONGODB_PASSWORD || '',
  MONGODB_DB_NAME: process.env.MONGODB_DB_NAME || 'nextech_ecommerce',
  ENABLE_MONGODB: Boolean(process.env.MONGODB_URI) && process.env.ENABLE_MONGODB !== 'false',
  // ChatOps & Multi-Channel Approval Notifications
  DISCORD_WEBHOOK_URL: process.env.DISCORD_WEBHOOK_URL || '',
  TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || '',
  TELEGRAM_CHAT_ID: process.env.TELEGRAM_CHAT_ID || '',
  ADMIN_NOTIFICATION_EMAIL: process.env.ADMIN_NOTIFICATION_EMAIL || process.env.ADMIN_DEFAULT_EMAIL || '',
  PUBLIC_API_URL: process.env.PUBLIC_API_URL || process.env.BACKEND_URL || 'http://localhost:5000',
  // Transactional Email & Order Security
  RESEND_API_KEY: process.env.RESEND_API_KEY || '',
  EMAIL_FROM: process.env.EMAIL_FROM || 'NexTech Security <no-reply@nextech.ae>',
  REQUIRE_ORDER_EMAIL_OTP: process.env.REQUIRE_ORDER_EMAIL_OTP !== 'false',
  // Tamara Buy Now Pay Later (GCC / UAE)
  TAMARA_API_URL: process.env.TAMARA_API_URL || 'https://api-sandbox.tamara.co',
  TAMARA_API_TOKEN: process.env.TAMARA_API_TOKEN || '',
  TAMARA_NOTIFICATION_TOKEN: process.env.TAMARA_NOTIFICATION_TOKEN || '',
  TAMARA_PUBLIC_KEY: process.env.TAMARA_PUBLIC_KEY || '',
  // Tabby Buy Now Pay Later (GCC / UAE)
  TABBY_API_URL: process.env.TABBY_API_URL || 'https://api.tabby.ai',
  TABBY_SECRET_KEY: process.env.TABBY_SECRET_KEY || '',
  TABBY_PUBLIC_KEY: process.env.TABBY_PUBLIC_KEY || '',
  TABBY_MERCHANT_CODE: process.env.TABBY_MERCHANT_CODE || 'nextech_ae',
};

