import { Response } from 'express';
import { pricingService } from '../services/pricing.service.js';
import { productRepository } from '../repositories/product.repository.js';
import { couponRepository } from '../repositories/coupon.repository.js';
import { orderRepository } from '../repositories/order.repository.js';
import { walletService } from '../services/wallet.service.js';
import { AuthenticatedRequest } from '../middleware/auth.js';

export class CartController {
  async calculateCart(req: AuthenticatedRequest, res: Response): Promise<void> {
    const { items, couponCode, requestedWalletDeduction, paymentMethod, shippingAddress, taxTreatment } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      res.json({
        success: true,
        data: {
          items: [],
          subtotal: 0,
          discount: 0,
          couponDiscount: 0,
          tax: 0,
          taxRate: 5,
          shippingFee: 0,
          paymentSurcharge: 0,
          paymentSurchargeRate: 0,
          codFee: 0,
          walletAmountUsed: 0,
          total: 0,
          currency: 'AED',
        },
      });
      return;
    }

    for (const it of items) {
      if (!it || typeof it.productId !== 'string' || !it.productId.trim()) {
        res.status(400).json({ success: false, error: { code: 'INVALID_ITEM', message: 'Item productId is required.' } });
        return;
      }
      const q = Number(it.quantity);
      if (!Number.isInteger(q) || q <= 0 || q > 999) {
        res.status(400).json({ success: false, error: { code: 'INVALID_QUANTITY', message: 'Item quantity must be a positive integer between 1 and 999.' } });
        return;
      }
      it.quantity = q;
    }

    const productIds = items.map((it: any) => it.productId);
    const productsMap = new Map<string, any>();

    for (const pid of productIds) {
      let p = await productRepository.findById(pid);
      if (!p) {
        p = await productRepository.findBySlug(pid);
      }
      if (p) {
        productsMap.set(pid, p);
      }
    }

    // Filter out items for products that no longer exist in the catalog
    const validItems = items.filter((it: any) => productsMap.has(it.productId));

    if (validItems.length === 0) {
      res.json({
        success: true,
        data: {
          items: [],
          subtotal: 0,
          discount: 0,
          couponDiscount: 0,
          tax: 0,
          taxRate: 5,
          shippingFee: 0,
          paymentSurcharge: 0,
          paymentSurchargeRate: 0,
          codFee: 0,
          walletAmountUsed: 0,
          total: 0,
          currency: 'AED',
        },
      });
      return;
    }

    let userWalletBalance = 0;
    if (req.user?.id) {
      userWalletBalance = await walletService.getBalance(req.user.id);
    }

    try {
      const result = await pricingService.calculateOrderTotals({
        items: validItems,
        productsMap,
        couponCode,
        requestedWalletDeduction: requestedWalletDeduction ? parseFloat(requestedWalletDeduction) : undefined,
        userWalletBalance,
        taxTreatment,
        paymentMethod,
        shippingAddress,
        userId: req.user?.id,
      });

      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(400).json({ success: false, error: { code: 'CART_CALCULATION_ERROR', message: err.message } });
    }
  }

  async validateCoupon(req: AuthenticatedRequest, res: Response): Promise<void> {
    const { code } = req.body;
    const subtotal = req.body.subtotal ?? req.body.cartSubtotal;
    if (!code) {
      res.status(400).json({ success: false, error: { code: 'BAD_REQUEST', message: 'Coupon code is required.' } });
      return;
    }

    const coupon = await couponRepository.findByCode(code);
    if (!coupon || !coupon.isActive) {
      res.status(404).json({ success: false, error: { code: 'COUPON_INVALID', message: 'Coupon is invalid or has expired.' } });
      return;
    }

    const now = new Date().toISOString();
    if (coupon.startDate > now || coupon.endDate < now) {
      res.status(400).json({ success: false, error: { code: 'COUPON_EXPIRED', message: 'This coupon has expired.' } });
      return;
    }

    if (coupon.usageLimit && (coupon.usageCount || 0) >= coupon.usageLimit) {
      res.status(400).json({ success: false, error: { code: 'COUPON_LIMIT_REACHED', message: 'This coupon has reached its maximum total usage limit.' } });
      return;
    }

    if (req.user?.id && coupon.perUserLimit && coupon.perUserLimit > 0) {
      const userOrders = await orderRepository.find({
        where: [
          { field: 'userId', operator: '==', value: req.user.id },
          { field: 'couponCode', operator: '==', value: coupon.code },
        ],
      });
      const activeOrders = userOrders.filter((o: any) => o.orderStatus !== 'CANCELLED');
      if (activeOrders.length >= coupon.perUserLimit) {
        res.status(400).json({ success: false, error: { code: 'COUPON_USER_LIMIT_REACHED', message: 'You have reached the maximum allowed uses for this coupon.' } });
        return;
      }
    }

    let discountAmount = 0;
    if (subtotal && subtotal > 0) {
      if (coupon.discountType === 'PERCENTAGE') {
        discountAmount = (subtotal * coupon.discountValue) / 100;
        if (coupon.maxDiscountAmount && discountAmount > coupon.maxDiscountAmount) {
          discountAmount = coupon.maxDiscountAmount;
        }
      } else {
        discountAmount = Math.min(coupon.discountValue, subtotal);
      }
    }

    res.json({
      success: true,
      data: {
        valid: true,
        code: coupon.code,
        discountType: coupon.discountType,
        discountValue: coupon.discountValue,
        discountAmount,
        minOrderAmount: coupon.minOrderAmount,
      },
    });
  }
}

export const cartController = new CartController();
