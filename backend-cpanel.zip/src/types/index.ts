export type UserRole = 'ADMIN' | 'CUSTOMER' | 'RESELLER' | 'PRODUCT_EDITOR';

export interface Address {
  id: string;
  fullName: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  isDefault?: boolean;
  isDefaultShipping?: boolean;
  isDefaultBilling?: boolean;
}

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name: string;
  username: string;
  phone?: string;
  avatar?: string;
  addresses: Address[];
  resellerId?: string; // If role is RESELLER
  company?: string;
  tradeLicense?: string;
  taxRegistrationNumber?: string;
  passwordHash?: string;
  adminPinHash?: string; // Secondary Admin Security PIN (PBKDF2 120,000 iterations)
  mfaEnabled?: boolean;
  mfaSecret?: string;
  mfaBackupCodes?: string[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
  passwordChangedAt?: string;
}

export type ResellerStatus = 'ACTIVE' | 'SUSPENDED' | 'PENDING_APPROVAL' | 'INACTIVE';

export interface ResellerBusinessInformation {
  taxNumber?: string; // 15-digit FTA TRN
  tradeLicense?: string;
  licenseJurisdiction?: string;
  licenseExpiryDate?: string;
  businessType?: string;
  specializations?: string[];
  authorizedSignatory?: string;
  signatoryTitle?: string;
  website?: string;
  description?: string;
  settlementTerms?: string;
  dispatchHub?: string;
}

export interface Reseller {
  id: string;
  userId: string;
  resellerCode: string; // e.g. "comnet101", "techhub"
  username: string;
  email: string;
  businessName: string;
  displayName: string;
  phone: string;
  logo?: string;
  subdomain: string; // e.g. "comnet101" -> comnet101.store.com
  address: Address;
  businessInformation: ResellerBusinessInformation;
  status: ResellerStatus;
  productCount: number;
  salesStats: {
    totalRevenue: number;
    totalOrders: number;
    unitsSold: number;
  };
  commissionRate?: number; // admin margin percentage if applicable
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
}

export type SellerType = 'ADMIN' | 'RESELLER';
export type ProductApprovalStatus = 'DRAFT' | 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'ACTIVE' | 'INACTIVE' | 'OUT_OF_STOCK' | 'ARCHIVED';

export interface ProductSpecification {
  categoryKey: string; // e.g. "processor", "ram", "storage", "gpu", "socket", "wattage", "formFactor"
  label: string; // e.g. "Processor Model", "Socket Type"
  value: string; // e.g. "Intel Core i9-14900K", "LGA1700"
}

export interface SEOData {
  metaTitle?: string;
  metaDescription?: string;
  canonicalUrl?: string;
  keywords?: string[];
}

export interface WarehouseLocationStock {
  locationId: string;
  locationName: string;
  city: string;
  quantity: number;
  reserved?: number;
  unavailable?: number;
  committed?: number;
  available?: number;
  onHand?: number;
}

export interface VariantOptionDefinition {
  name: string; // e.g. "RAM", "Storage", "Color"
  values: string[]; // e.g. ["16GB", "32GB"]
}

export interface ProductVariant {
  id: string;
  sku: string;
  barcode?: string;
  title: string; // e.g. "16GB RAM / 512GB SSD / Silver"
  price: number;
  compareAtPrice?: number;
  costPrice?: number;
  stock: number;
  options: Record<string, string>; // e.g. { "RAM": "16GB", "Storage": "512GB", "Color": "Silver" }
  image?: string;
  chargeTax?: boolean;
  weight?: number;
  locations?: WarehouseLocationStock[];
  isActive?: boolean;
}

export interface ProductPackageDimensions {
  length: number;
  width: number;
  height: number;
  unit: 'cm' | 'in';
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  sku: string;
  barcode?: string;
  brandId: string;
  brandName: string;
  categoryId: string;
  categoryName: string;
  subcategoryId?: string;
  sellerType: SellerType;
  resellerId?: string;
  resellerCode?: string;
  resellerName?: string;
  description?: string;
  shortDescription?: string;
  price: number;
  salePrice?: number;
  compareAtPrice?: number;
  costPrice?: number;
  currency: string;
  stock: number;
  reservedStock: number;
  lowStockThreshold: number;
  locations?: WarehouseLocationStock[];
  images: string[];
  thumbnail: string;
  specifications: Record<string, string>; // normalized key-values e.g. { socket: "LGA1700", ramType: "DDR5", wattage: "125W" }
  features: string[];
  tags: string[];
  collections?: string[];
  warranty?: string;
  rating: number;
  reviewCount: number;
  isFeatured: boolean;
  isActive: boolean;
  approvalStatus: ProductApprovalStatus;
  rejectionReason?: string;
  seo?: SEOData;
  // Multi-variant support
  hasVariants?: boolean;
  variantOptions?: VariantOptionDefinition[];
  variants?: ProductVariant[];
  // Logistics & Shipping
  weight?: number; // In kilograms (kg)
  dimensions?: ProductPackageDimensions;
  hsCode?: string; // Harmonized System tariff code
  isPhysical?: boolean; // Physical vs Digital toggle
  // Tax & Pricing policy
  chargeTax?: boolean; // Defaults to true; if false, exempt from VAT
  unitPrice?: number;
  unitMeasure?: string; // e.g. "item", "kg", "meter"
  // Inventory tracking & policy
  inventoryTracked?: boolean;
  allowBackorder?: boolean; // "Sell when out of stock" policy
  status?: 'ACTIVE' | 'DRAFT' | 'ARCHIVED';
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
  image?: string;
  parentId?: string | null;
  order: number;
  isActive: boolean;
  productCount: number;
}

export interface Brand {
  id: string;
  name: string;
  slug: string;
  logo?: string;
  description?: string;
  website?: string;
  isActive: boolean;
  productCount: number;
}

export interface CartItem {
  productId: string;
  productName: string;
  variantId?: string;
  variantTitle?: string;
  options?: Record<string, string>;
  sku: string;
  slug: string;
  image: string;
  quantity: number;
  price: number;
  salePrice?: number;
  chargeTax?: boolean;
  sellerType: SellerType;
  resellerId?: string;
  resellerCode?: string;
  subtotal: number;
  unitPrice?: number;
  totalPrice?: number;
  stockAvailable: number;
}

export interface Cart {
  userId?: string;
  sessionId?: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  tax: number;
  shipping: number;
  total: number;
  updatedAt: string;
}

export type OrderStatus = 'PENDING' | 'PENDING_APPROVAL' | 'CONFIRMED' | 'PROCESSING' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED' | 'RETURNED' | 'REFUNDED';
export type PaymentStatus = 'PENDING' | 'AUTHORIZED' | 'PAID' | 'FAILED' | 'REFUNDED';
export type PaymentMethod = 'CREDIT_CARD' | 'WALLET' | 'COD' | 'BANK_TRANSFER' | 'TAMARA' | 'TABBY' | 'IN_STORE';

export interface OrderItem {
  productId: string;
  productName: string;
  variantId?: string;
  variantTitle?: string;
  options?: Record<string, string>;
  title?: string;
  sku: string;
  slug: string;
  thumbnail: string;
  image?: string;
  quantity: number;
  unitPrice: number;
  price?: number;
  discount: number;
  chargeTax?: boolean;
  subtotal: number;
  sellerType: SellerType;
  resellerId?: string;
  resellerCode?: string;
  brandName?: string;
  categoryName?: string;
  specifications?: Record<string, string>;
  serialNumbers?: string[];
  warrantyMonths?: number;
  warrantyExpiry?: string;
}

export interface OrderStatusHistoryItem {
  status: OrderStatus;
  note?: string;
  timestamp: string;
  updatedBy?: string;
}

export interface OrderPaymentMetadata {
  provider?: 'TAMARA' | 'TABBY';
  checkoutId?: string;
  orderId?: string;
  paymentId?: string;
  captureId?: string;
  redirectUrl?: string;
  installments?: number;
  isSimulated?: boolean;
  raw?: any;
}

export interface CargoMilestone {
  stage: string;
  location: string;
  timestamp: string;
  completed: boolean;
  notes?: string;
}

export interface CargoDetails {
  waybillNumber?: string;
  trackingNumber?: string;
  carrier?: string;
  cargoType?: string;
  weightKg?: number;
  packageCount?: number;
  dimensions?: string;
  volumetricWeightKg?: number;
  originHub?: string;
  destinationHub?: string;
  customsStatus?: 'CLEARED' | 'IN_INSPECTION' | 'DOCUMENTATION_REQUIRED' | 'EXEMPT';
  customsDeclarationNumber?: string;
  driverName?: string;
  driverPhone?: string;
  vehiclePlate?: string;
  estimatedDeliveryDate?: string;
  dispatchedAt?: string;
  milestones?: CargoMilestone[];
  notes?: string;
}

export interface Order {
  id: string;
  orderNumber: string; // e.g. "ORD-2026-89421"
  userId: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  inStoreDiscount?: number;
  inStoreDiscountRate?: number;
  walletAmountUsed: number;
  tax: number;
  taxRate: number;
  shippingFee: number;
  paymentSurcharge?: number;
  paymentSurchargeRate?: number;
  codFee?: number;
  total: number;
  currency: string;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  paymentReference?: string;
  paymentMetadata?: OrderPaymentMetadata;
  orderStatus: OrderStatus;
  shippingAddress: Address;
  billingAddress: Address;
  statusHistory: OrderStatusHistoryItem[];
  notes?: string;
  eBillId?: string;
  customerType?: 'INDIVIDUAL' | 'BUSINESS';
  companyName?: string;
  tradeLicense?: string;
  trn?: string;
  contactPerson?: string;
  contactRole?: string;
  poNumber?: string;
  paymentTerms?: string;
  taxTreatment?: string;
  partnerTier?: string;
  inStoreReservationExpiry?: string;
  carrier?: string;
  trackingNumber?: string;
  cargoDetails?: CargoDetails;
  createdAt: string;
  updatedAt: string;
}

export type WalletTransactionType = 'CREDIT' | 'DEBIT' | 'REFUND' | 'ADMIN_ADJUSTMENT';

export interface WalletTransaction {
  id: string;
  userId: string;
  type: WalletTransactionType;
  amount: number;
  balanceBefore: number;
  balanceAfter: number;
  reason: string;
  referenceId?: string; // OrderId or AdminId
  createdAt: string;
}

export interface Wallet {
  id: string;
  userId: string;
  balance: number;
  currency: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export type CouponDiscountType = 'PERCENTAGE' | 'FIXED';

export interface Coupon {
  id: string;
  code: string;
  title?: string;
  description?: string;
  badgeText?: string;
  ctaText?: string;
  ctaLink?: string;
  discountType: CouponDiscountType;
  discountValue: number;
  minOrderAmount: number;
  maxDiscountAmount?: number;
  usageLimit?: number;
  usageCount: number;
  perUserLimit: number;
  applicableCategoryIds?: string[];
  applicableBrandIds?: string[];
  applicableProductIds?: string[];
  customerEligibility?: 'ALL' | 'B2B_ONLY' | 'VIP_ONLY';
  resellerId?: string;
  showOnLandingPage?: boolean;
  startDate: string;
  endDate: string;
  isActive: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  title: string;
  comment: string;
  isVerifiedPurchase: boolean;
  isApproved: boolean;
  createdAt: string;
}

export interface EBill {
  id: string;
  orderId: string;
  orderNumber: string;
  invoiceNumber: string; // e.g. "INV-2026-90412"
  issuedDate: string;
  dueDate: string;
  sellerInfo: {
    name: string;
    taxNumber: string;
    address: string;
    phone: string;
    email: string;
    stampUrl?: string;
    signatureUrl?: string;
    signatoryName?: string;
    signatoryTitle?: string;
    showStamp?: boolean;
    showSignature?: boolean;
  };
  stampUrl?: string;
  signatureUrl?: string;
  signatoryName?: string;
  signatoryTitle?: string;
  showStamp?: boolean;
  showSignature?: boolean;
  customerInfo: {
    name: string;
    email: string;
    phone?: string;
    address: Address;
    customerType?: 'INDIVIDUAL' | 'BUSINESS';
    companyName?: string;
    tradeLicense?: string;
    trn?: string;
    contactPerson?: string;
    contactRole?: string;
    poNumber?: string;
    paymentTerms?: string;
    taxTreatment?: string;
    partnerTier?: string;
  };
  items: OrderItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  tax: number;
  shipping: number;
  paymentSurcharge?: number;
  paymentSurchargeRate?: number;
  codFee?: number;
  walletDeduction: number;
  total: number;
  currency: string;
  paymentMethod: string;
  paymentStatus: string;
  downloadUrl?: string;
  termsAndConditions?: string;
  createdAt: string;
}

export interface PCBuilderCategorySlots {
  cpu?: Product | null;
  motherboard?: Product | null;
  ram?: Product | null;
  gpu?: Product | null;
  storage?: Product | null;
  psu?: Product | null;
  case?: Product | null;
  cooler?: Product | null;
}

export interface CompatibilityIssue {
  type: 'ERROR' | 'WARNING';
  category: string;
  message: string;
  affectedComponents: string[];
}

export interface PCBuilderCompatibilityResult {
  isCompatible: boolean;
  totalEstimatedWattage: number;
  recommendedPsuWattage: number;
  issues: CompatibilityIssue[];
  totalPrice: number;
}

export interface ProductImportRow {
  rowNumber: number;
  data: Record<string, string>;
  normalizedProduct?: Partial<Product>;
  missingRequiredFields: string[];
  invalidFields: { field: string; message: string }[];
  isDuplicateSku: boolean;
  isValid: boolean;
}

export interface ProductImportReport {
  id: string;
  resellerId: string;
  resellerCode: string;
  fileName: string;
  totalRows: number;
  validRows: number;
  errorRows: number;
  duplicateRows: number;
  importedCount: number;
  status: 'PREVIEW' | 'COMPLETED' | 'FAILED';
  errors: { row: number; field: string; message: string }[];
  createdAt: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userEmail: string;
  userRole: UserRole;
  resellerId?: string;
  action: string;
  resource: string;
  resourceId?: string;
  details: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
  createdAt: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle?: string;
  linkUrl: string;
  buttonText: string;
  imageUrl: string;
  badge?: string;
  position: 'HERO' | 'PROMO_SECTION' | 'SIDEBAR' | 'POPUP';
  order: number;
  isActive: boolean;
  startDate?: string;
  endDate?: string;
}

export interface StoreSettings {
  storeName: string;
  supportEmail: string;
  supportPhone: string;
  defaultCurrency: string;
  currencySymbol: string;
  taxRate: number; // e.g. 5 for 5% VAT
  standardShippingFee: number;
  freeShippingThreshold: number;
  address: string;
  taxRegistrationNumber: string;
  announcementText?: string;
  isAnnouncementActive: boolean;
  isLandingDiscountBannerActive?: boolean;
  featuredLandingCouponCode?: string;
  logoUrl?: string;
  faviconUrl?: string;
  storefrontSections?: StorefrontSectionConfig[];
  socialLinks?: {
    facebook?: string;
    twitter?: string;
    instagram?: string;
    linkedin?: string;
  };
  // Official Tax Invoice / E-Bill Digital Stamp & Signature
  invoiceStampUrl?: string;
  invoiceSignatureUrl?: string;
  signatoryName?: string;
  signatoryTitle?: string;
  showStampOnEBill?: boolean;
  showSignatureOnEBill?: boolean;
  invoiceTermsAndConditions?: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  meta?: {
    total?: number;
    page?: number;
    limit?: number;
    totalPages?: number;
    [key: string]: any;
  };
}

export interface HeroHighlight {
  id: string;
  tabLabel: string;
  name: string;
  brand: string;
  category: string;
  badge: string;
  iconName: string;
  specs: { label: string; value: string }[];
  matchQueries: string[];
  defaultImage: string;
  defaultPrice: number;
  tagline: string;
  powerRating: string;
  order: number;
  isActive: boolean;
}

export interface EnterpriseSolution {
  id: string;
  title: string;
  badge: string;
  badgeColor: string;
  glowColor: string;
  borderColor: string;
  iconName: string;
  benchmarkScore: string;
  description: string;
  specs: string[];
  popularSku: string;
  skuPrice: string;
  link: string;
  order: number;
  isActive: boolean;
}

export interface BenchmarkItem {
  name: string;
  score: number;
  maxScore: number;
  isTop?: boolean;
  badge?: string;
}

export interface HardwareBenchmarkCategory {
  id: string;
  label: string;
  iconName: string;
  title: string;
  metric: string;
  benchmarks: BenchmarkItem[];
  note: string;
  order: number;
  isActive: boolean;
}

export interface ClientTestimonial {
  id: string;
  name: string;
  initials: string;
  role: string;
  company: string;
  rating: number;
  workload: string;
  text: string;
  badge: string;
  avatarColor: string;
  order: number;
  isActive: boolean;
}

export interface BentoFeature {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  tag: string;
  iconName: string;
  gridSpan: number; // 7 or 5
  stats?: { label: string; value: string }[];
  ctaText?: string;
  ctaLink?: string;
  statusBadge?: string;
  order: number;
  isActive: boolean;
}

export interface BuilderPreset {
  id: string;
  name: string;
  socket: string;
  cpu: string;
  gpu: string;
  ram: string;
  psuWatts: number;
  estTotalWatts: number;
  headroomPercent: number;
  order: number;
  isActive: boolean;
}

export interface HomePageContent {
  heroHighlights: HeroHighlight[];
  solutions: EnterpriseSolution[];
  benchmarks: HardwareBenchmarkCategory[];
  testimonials: ClientTestimonial[];
  features: BentoFeature[];
  builderPresets: BuilderPreset[];
  activeCoupon?: Coupon;
  storeSettings?: StoreSettings;
  stats: {
    totalProducts: number;
    totalCategories: number;
    totalBrands: number;
    authorizedPartnersCount: number;
  };
}

// Purchase Orders & Restock Types
export type POStatus = 'DRAFT' | 'ISSUED' | 'RECEIVED' | 'CANCELLED';

export interface POLineItem {
  productId: string;
  sku: string;
  title: string;
  name?: string;
  categoryName?: string;
  brandName?: string;
  currentStock: number;
  lowStockThreshold: number;
  suggestedReorderQuantity: number;
  orderedQuantity: number;
  receivedQuantity?: number;
  serialNumbers?: string[];
  quantity?: number;
  unitCost: number;
  totalCost: number;
  subtotal?: number;
  supplierName?: string;
}

export interface SupplierCompanyDetails {
  legalName: string;
  tradeLicenseNumber?: string;
  taxRegistrationNumber?: string; // TRN
  country: string;
  city: string;
  addressLine: string;
  contactPerson: string;
  contactEmail: string;
  contactPhone: string;
  paymentTerms?: string;
  incoterms?: string;
  vendorCode?: string;
}

export interface BuyerCompanyDetails {
  legalName: string;
  taxRegistrationNumber: string;
  corporateAddress: string;
  contactPerson: string;
  contactEmail: string;
  contactPhone?: string;
  billingCurrency: string;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string; // e.g. "PO-2026-0901"
  status: POStatus;
  items: POLineItem[];
  totalUnits: number;
  totalEstimatedCost: number;
  totalCost?: number;
  currency: string;
  targetWarehouse: string; // e.g. "loc_dxb_main"
  destinationLocation?: string;
  supplierName: string;
  supplierDetails?: SupplierCompanyDetails;
  buyerDetails?: BuyerCompanyDetails;
  paymentTerms?: string;
  deliveryTerms?: string;
  freightCarrier?: string;
  trackingNumber?: string;
  expectedDeliveryDate?: string;
  taxRate?: number;
  taxAmount?: number;
  notes?: string;
  issuedAt?: string;
  receivedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// B2B Corporate Quotations Types
export type QuoteStatus = 'DRAFT' | 'PENDING_REVIEW' | 'APPROVED' | 'CONVERTED' | 'REJECTED' | 'EXPIRED';

export interface QuoteItem {
  productId: string;
  productName: string;
  sku: string;
  unitPrice: number;
  quantity: number;
  discount: number;
  subtotal: number;
  specifications?: Record<string, string>;
}

export interface Quote {
  id: string;
  quoteNumber: string; // e.g. "QTE-2026-89412"
  companyName: string;
  contactName: string;
  contactEmail: string;
  contactPhone?: string;
  tradeLicense?: string;
  taxRegistrationNumber?: string;
  clientReference?: string;
  paymentTerms?: string;
  deliverySLA?: string;
  taxTreatment?: string;
  items: QuoteItem[];
  subtotal: number;
  discount: number;
  tax: number;
  shipping: number;
  total: number;
  currency: string;
  status: QuoteStatus;
  validUntil: string;
  notes?: string;
  convertedOrderId?: string;
  createdAt: string;
  updatedAt: string;
}

// Visual Storefront CMS Section Configuration
export interface StorefrontSectionConfig {
  id: string; // e.g. "hero", "voucher_banner", "catalog_matrix", "enterprise_bento", "benchmarks", "testimonials", "partner_stores"
  title: string;
  name?: string;
  subtitle?: string;
  description?: string;
  isVisible?: boolean;
  enabled?: boolean;
  order: number;
}

// Database Snapshot & Disaster Recovery
export interface DbSnapshot {
  id: string;
  filename: string;
  timestamp: string;
  collectionCount: number;
  totalRecords: number;
  sizeBytes: number;
  collections: Record<string, any[]>;
}

export type NotificationCategory =
  | 'ORDERS'
  | 'INVENTORY'
  | 'RESELLERS'
  | 'PRODUCTS'
  | 'QUOTES'
  | 'PURCHASE_ORDERS'
  | 'SYSTEM';

export type NotificationSeverity = 'CRITICAL' | 'WARNING' | 'INFO';

export interface AdminNotification {
  id: string;
  type: string;
  title: string;
  message: string;
  category: NotificationCategory;
  severity: NotificationSeverity;
  actionRequired: boolean;
  actionUrl: string;
  actionLabel: string;
  isRead: boolean;
  createdAt: string;
  metadata?: Record<string, any>;
}

export interface AdminNotificationsResponse {
  notifications: AdminNotification[];
  unreadCount: number;
  actionRequiredCount: number;
  criticalCount: number;
  lastSyncedAt: string;
}


